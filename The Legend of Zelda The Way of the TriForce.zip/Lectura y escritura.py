puntos = open("Puntajes.txt",'a+')
puntos.write("\nabc,231")
puntos.seek(0)
